package elementosDoDominio;
import java.io.Serializable;
import java.util.ArrayList;

public abstract class Vacina implements Serializable {
    protected String nomeVacina;
    protected String fabricante;
    protected String doenca;
    protected String tipo;
    protected String informacaoAdicional;
    
    public Vacina() {
    	
    }

    public Vacina(String nomeVacina, String doenca, String tipo, String informacaoAdicional) {
        this.nomeVacina = nomeVacina;
        this.doenca = doenca;
        this.tipo = tipo;
        this.informacaoAdicional = informacaoAdicional;
    }
    public Vacina(String nomeVacina, String fabricante, String doenca, String tipo, String informacaoAdicional) {
        this(nomeVacina,doenca, tipo, informacaoAdicional);
        this.fabricante = fabricante;
    }
    
    public String getTipo() {
		return tipo;
	}

    public String getInformacaoAdicional() {
		return informacaoAdicional;
	}

	public String getNomeVacina() {
        return this.nomeVacina;
    }

    public String getDoenca() {
        return this.doenca;
    }

    public String getFabricante() {
        return this.fabricante;
    
    }
    
    @Override
    public String toString() {
    	return nomeVacina + ";" + fabricante + ";" + doenca + ";" + tipo + ";" + informacaoAdicional;
    }

}
    
   

	
