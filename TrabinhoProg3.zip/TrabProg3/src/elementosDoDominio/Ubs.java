package elementosDoDominio;
import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Ubs implements Serializable {
	
	SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
	SimpleDateFormat formato2 = new SimpleDateFormat("dd/MM/yyyy HH:mm");

    private String nome;
    private String sigla;
    private int totalVacinados = 0;
    private int totalAgendados = 0;
    private int totalCancelamentos = 0;
    private int auxiliaAgendados = 0;   /** Variavel que contabiliza a quantidade de operacoes de agendamento efetuação e cancelamentos em uma UBS*/
    private Date periodoInicial;
    private Date periodoFinal;
    
    public Ubs(String nome, String sigla) {
        this.nome = nome;
        this.sigla = sigla;
    }
    
    public int getTotalVacinados() {
		return totalVacinados;
	}

	public int getTotalAgendados() {
		return totalAgendados;
	}

	public int getTotalCancelamentos() {
		return totalCancelamentos;
	}
	
    public Date getPeriodoInicial() {
		return periodoInicial;
	}

	public void setPeriodoInicial(Date periodoInicial) {
		this.periodoInicial = periodoInicial;
	}

	public Date getPeriodoFinal() {
		return periodoFinal;
	}

	public void setPeriodoFinal(Date periodoFinal) {
		this.periodoFinal = periodoFinal;
	}

    public String getNome() {
        return this.nome;
    }

    public String getSigla() {
        return this.sigla;
    }
    
    public int getAuxiliaAgendados() {
    	return this.auxiliaAgendados;
    }

    public void contaVacinados() {
    	this.totalVacinados++;
    }
    
    public void incrementaAuxiliar() {
    	this.auxiliaAgendados++;
    }
    
    public void decrementaVacinados() {
    	this.totalVacinados--;
    }
    
    public void contaAgendados() {
    	this.totalAgendados++;
    }
    
    public void decrementaAgendados() {
    	this.totalAgendados--;
    }
    
    public void contaCancelados() {
    	this.totalCancelamentos++;
    }
    
    public void daPeriodoInicial(Date dataRegistrada) {
         if(dataRegistrada.compareTo(this.periodoInicial) < 0) {
            System.out.println("Date 1 occurs before Date 2");
            this.periodoInicial = dataRegistrada; //nova data registrada eh anterior, portanto subtitui a antiga data
         }
    }
    
    public void daPeriodoFinal(Date dataRegistrada) {
        if(dataRegistrada.compareTo(this.periodoFinal) > 0) {
           System.out.println("Date 1 occurs before Date 2");
           this.periodoFinal = dataRegistrada; //nova data registrada eh posterior, portanto subtitui a antiga data
        }
        
   }
    
  
    @Override
    public String toString() {
        return nome + ";" + totalVacinados + ";" + totalAgendados + ";" + totalCancelamentos + ";" + ConvertDateToString(periodoInicial) + " a " + ConvertDateToString(periodoFinal);
    }
    
    public String ConvertDateToString(Date dataEHora){
    	DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        String dataFormatada = dateFormat.format(dataEHora);
        return dataFormatada;
    }

}
