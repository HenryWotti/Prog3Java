package entradaSaida;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import elementosDoDominio.AgendarVacinacao;
import elementosDoDominio.Listas;
import elementosDoDominio.Lote;
import elementosDoDominio.ServidorMunicipal;
import elementosDoDominio.Ubs;
import elementosDoDominio.Vacina;

public class Escritor  implements Serializable{
	private File arquivoDeSerializacao;
	private ArrayList<Ubs> listUbs = new ArrayList<Ubs>();
	private ArrayList<ServidorMunicipal> listServidor = new ArrayList<ServidorMunicipal>();
	private ArrayList<Vacina> listVacina = new ArrayList<Vacina>();
	private ArrayList<Lote> listLotes = new ArrayList<Lote>();
	private ArrayList<AgendarVacinacao> listAgendamentos = new ArrayList<AgendarVacinacao>();
	
	public Escritor() {
		
	}
	
	public void escritor(String nomeDoArquivoSerializacao) {
		arquivoDeSerializacao = new File (nomeDoArquivoSerializacao);
	}
	
	public void serializar(ArrayList<Object> dados) {
		try {
			FileOutputStream fileOut = new FileOutputStream("dados.dat");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(dados);
			out.close();
			fileOut.close();
			
		} catch(IOException i){
			i.printStackTrace();
		}
	}
	
	public ArrayList<Object> desserializar() {
		ArrayList<Object> deserialized = new ArrayList<Object>();
		
		try {
			FileInputStream fileIn = new FileInputStream("dados.dat");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			deserialized = (ArrayList<Object>)in.readObject();
			in.close();
			fileIn.close();
			return deserialized;
		} catch(IOException i){
			i.printStackTrace();
			return null;
		} catch(ClassNotFoundException c){
			c.printStackTrace();
			return null;
		}

	}
}

