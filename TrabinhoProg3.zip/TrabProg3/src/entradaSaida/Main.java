package entradaSaida;
import java.util.Scanner;

import interfaceUsuario.Inputs;
import interfaceUsuario.Menu;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.Locale;
import java.util.ArrayList;

public class Main implements Serializable{
	
	
    public static void main(String[] args) throws ParseException {

        //Locale.setDefault(new Locale("pt", "BR"));
        Scanner scan = new Scanner(System.in);

        /** Para algumas leituras de numero seguidas de nextLine é preciso ler o lixo
         * para pegar o enter depois do número.*/
        String lixo;

        /** A opcao será a chave do switch para saber qual operacao o usuario deseja
         * efetuar */
        int opcao = 0;

        Menu m = new Menu();
        
        /** Declaramos aqui um objeto Arquivo que será ultilizado para chamar métodos auxiliares */
        Arquivo arqLeitura = new Arquivo();
        /** Variavel que irá guardar se a opcao read-only foi passada*/
        boolean precisaSerializar = false;
        boolean somenteDesserializar = false;
        /** Esse while pega os argumento recebidos e opera de acordo, irá ler o nome
         * do arquivo que está mo proximo argumento caso seja -u -s -l -v ou -a
         * Caso seja read-only além de receber os arquivos, eles devem ser serializados
         * após a montagem das estrutras, em um arquivo chamado dados.dat
         * Caso seja write-only o programa não recebera nenhum arquivo, ele irá
         *  desserializar o dados.dat e gerar os relatórios */
        String argumento;
        int i = 0;
        while(i<args.length) {
        	argumento= args[i];
            
            /** Caso seja write-only basta desserializar o dados.dat, imprimir os relatorios e acabar o programa */
             if (argumento.compareTo("--write-only") == 0 ) {
            	somenteDesserializar = true;
             	m.escolheMenu(8, arqLeitura);
             	break;
             } 
             /** Se esse argumento foi passado então sabemos que após a criacao das estruturas
              * devemos serializa-las*/
             if (argumento.compareTo("--read-only") == 0) {
             	precisaSerializar = true;
             	i++;
             	continue;
             }
             
             /** Aqui teremos como argumento o nome do arquivo no args[i+1], mas não queremos simplesmente
              * abrir e ler todos os arquivos de qualquer maneira, queremos primeiro fazer 
              * o cadastro das ubs, depois dos servidores e assim por diante*/
             /** Então teremos atributos dentro do arquivo, que irão guardar o conteudo dos arquivos.
              * Depois de abrir todos, eles serão mandados na ordem certa para montagem das estruturas*/
             Arquivo.operaArgumento(arqLeitura, args[i+1]);
             i = i+2;
        }
        
        /** Aqui temos todo o conteudo dos arquivos já salvos dentro dos atributos da classe Arquivo, ou seja, independente da ordem
         * que esses arquivos forem enviados, agora vamos cadastrar na ordem que quisermos*/
        
        	/** Caso a opção de desserializar tenha sido passada como parametro não precisamos realizar os cadastros abaixo*/
        	if(somenteDesserializar == false) {
        	/** Cadastrando todas as UBSs */
            	m.escolheMenu(1, arqLeitura);
            /** Cadastrando todos os Servidores */
            	m.escolheMenu(2, arqLeitura);
            /** Cadastrando todas as Vacinas */
            	m.escolheMenu(3, arqLeitura);
            /** Cadastrando todos os Lotes */
            	m.escolheMenu(4, arqLeitura);
            /** Cadastrando todos os Agendamentos */
            	m.escolheMenu(5, arqLeitura);
        	}
        
        	
        	
        /** Após colocar todos os dados nas estruturas, agora iremos gerar os relatórios */
        	m.escolheMenu(6, arqLeitura);
        /** Caso o argumento read-only foi passado, temos que serializar nossos dados*/
        	if(precisaSerializar == true) {
        		m.escolheMenu(7, arqLeitura);
        	};
        
        	
        
        scan.close();
    }
}
