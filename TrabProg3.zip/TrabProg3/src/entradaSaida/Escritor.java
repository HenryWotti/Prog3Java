package entradaSaida;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import elementosDoDominio.AgendarVacinacao;
import elementosDoDominio.Lote;
import elementosDoDominio.ServidorMunicipal;
import elementosDoDominio.Ubs;
import elementosDoDominio.Vacina;

public class Escritor  implements Serializable{
	/** Classe responsavel pela serializacao e desserializacao 
	 * Manipula uma ArrayList<Object> que contém todos os dados necessários
	 * para a impressão dos relatórios */
	public Escritor() {
		
	}
	
	public void serializar(ArrayList<Object> dados) {
		try {
			FileOutputStream fileOut = new FileOutputStream("dados.dat");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(dados);
			out.close();
			fileOut.close();
			
		} catch(IOException i){
			i.printStackTrace();
		}
	}
	
	public ArrayList<Object> desserializar() {
		ArrayList<Object> deserialized = new ArrayList<Object>();
		
		try {
			FileInputStream fileIn = new FileInputStream("dados.dat");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			deserialized = (ArrayList<Object>)in.readObject();
			in.close();
			fileIn.close();
			return deserialized;
		} catch(IOException i){
			i.printStackTrace();
			return null;
		} catch(ClassNotFoundException c){
			c.printStackTrace();
			return null;
		}

	}
}

