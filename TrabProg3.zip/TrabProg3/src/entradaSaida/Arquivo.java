package entradaSaida;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Arquivo {
	/** Classe que guarda as strings contendo todo o conteúdo dos arquivos para depois
	 * serem utilizados em uma ordem que faça sentido */
	String arqUbs;
	String arqServidor;
	String arqVacina;
	String arqLote;
	String arqAgendamento;
	
	public String getArqUbs() {
		return arqUbs;
	}

	public void setArqUbs(String arqUbs) {
		this.arqUbs = arqUbs;
	}

	public String getArqServidor() {
		return arqServidor;
	}

	public void setArqServidor(String arqServidor) {
		this.arqServidor = arqServidor;
	}

	public String getArqVacina() {
		return arqVacina;
	}

	public void setArqVacina(String arqVacina) {
		this.arqVacina = arqVacina;
	}

	public String getArqLote() {
		return arqLote;
	}

	public void setArqLote(String arqLote) {
		this.arqLote = arqLote;
	}

	public String getArqAgendamento() {
		return arqAgendamento;
	}

	public void setArqAgendamento(String arqAgendamento) {
		this.arqAgendamento = arqAgendamento;
	}

	public static String leitura(String caminho) {
		String conteudo = "";
		try {
			FileReader arq = new FileReader(caminho);
			BufferedReader lerArq = new BufferedReader(arq);
			String linha = "";
			try {
				linha = lerArq.readLine();
				while(linha!=null) {
					conteudo += linha + "\n";
					linha = lerArq.readLine();
				}
				arq.close();
			} catch (IOException ex) {
				conteudo = "Erro: Não foi possível ler o arquivo!";
			}
		} catch (FileNotFoundException ex) {
			conteudo = "Erro: Arquivo não encontrado!";
		}
		if(conteudo.contains("Erro")) {
			return "";
		} else {
			return conteudo;
		}
	}
	
	public static boolean escrita(String caminho, String texto) {
		try {
			FileWriter arq = new FileWriter (caminho);
			PrintWriter gravarArq = new PrintWriter(arq);
			gravarArq.println(texto);
			gravarArq.close();
			return true;
		} catch (IOException e) {
			System.out.println(e.getMessage());
			return false;
		}
	}
	
	public static void operaArgumento(Arquivo arq, String argumento) {
		switch(argumento) {
			case "unidades.csv" :		arq.setArqUbs(leitura("unidades.csv"));
										break;
			case "servidores.csv" :		arq.setArqServidor(leitura("servidores.csv"));
										break;
			case "vacinas.csv" :		arq.setArqVacina(leitura("vacinas.csv"));
										break;
			case "lotes.csv" :			arq.setArqLote(leitura("lotes.csv"));
										break;
			case "agendamentos.csv" :	arq.setArqAgendamento(leitura("agendamentos.csv"));
										break;
			default :					System.out.println("Erro: argumento invalido!");
		}
	}
	
}
