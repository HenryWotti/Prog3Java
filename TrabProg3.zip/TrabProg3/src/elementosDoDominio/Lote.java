package elementosDoDominio;
import java.io.Serializable;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.Period;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.time.ZonedDateTime;

import entradaSaida.Arquivo;

public class Lote implements Serializable {
	/** Essa classe é responsável pelos métodos de gerenciamento de lotes, além
	 * da geração do relatório 2 e os métodos de ordenação necessários pra tal relatório*/
    private Vacina vacina;
    private Ubs ubs;
    private Date data;
    private int quantidade;
    private double custoPorDose;
    private String fonte;
    
    public Lote() {
    	
    }
    
    public Lote(Vacina vacina, Ubs ubs, Date data, int quantidade, double custoPorDose, String fonte) {
        this.vacina = vacina;
        this.ubs = ubs;
        this.data = data;
        this.quantidade = quantidade;
        this.custoPorDose = custoPorDose;
        this.fonte = fonte;
    }

    public Vacina getVacina() {
        return this.vacina;
    }

    public Ubs getUbs() {
        return this.ubs;
    }

    public Date getData() {
        return this.data;
    }

    public int getQuantidade() {
        return this.quantidade;
    }

    public double getCustoPorDose() {
        return this.custoPorDose;
    }

    public String getFonte() {
        return this.fonte;
    }
    
    public void relatorio2(ArrayList<Vacina> listaVacinas, ArrayList<String> listaNomeDoencas, ArrayList<Lote> listaLotes) {
    	NumberFormat formatinho = NumberFormat.getInstance(Locale.FRANCE);
    	DecimalFormat df2 = new DecimalFormat("#,##");
    	ArrayList<Date> listaDatas = new ArrayList<Date>();
    	int contTotalDoses = 0;
		int contDosesFederal = 0;
		double contCustoFederal = 0.00;
		int contDosesEstadual = 0;
		double contCustoEstadual = 0;
		String federal = "F";
		double mediaFederal = 0.00;
		double mediaEstadual = 0.00;
		
		String conteudo = "Doença;Vacinas;Doses Recebidas;Custo Médio da Dose (Federal);Custo Médio da Dose (Estadual);Intervalo Médio Entregas (Dias)";
		Arquivo arqEscrita = new Arquivo();
		String nomeArquivo = "2-entregas.csv";
		
		ordenaVacina(listaVacinas);
		//System.out.println(listaVacinas);
		ordenaDoenca(listaNomeDoencas);
		for(int i = 0; i < listaNomeDoencas.size(); i++) {
			conteudo += "\n" + listaNomeDoencas.get(i) + ";";

			for (int j = 0 ; j < listaVacinas.size(); j++) {
               
				if(listaNomeDoencas.get(i).compareTo(listaVacinas.get(j).getDoenca()) == 0) {
                	conteudo += listaVacinas.get(j).getNomeVacina() + "/" + listaVacinas.get(j).getFabricante() + ", ";
                	
                
                	for(int k = 0; k < listaLotes.size(); k++) {
                		if(listaVacinas.get(j).getNomeVacina().compareTo(listaLotes.get(k).getVacina().getNomeVacina()) == 0) {
                			contTotalDoses += listaLotes.get(k).getQuantidade(); //quantidade total de doses recebidas para a doenca
                			
                			/** Pega as datas de entrega dos lotes das vacinas para a doenca analisada */
                			listaDatas.add(listaLotes.get(k).getData());
                			
                			if(listaLotes.get(k).getFonte().compareTo(federal) == 0){
                				contDosesFederal+= listaLotes.get(k).getQuantidade(); //total de doses vindas do governo federal
                				contCustoFederal += listaLotes.get(k).getCustoPorDose() *  listaLotes.get(k).getQuantidade(); //soma dos custos das doses federais com peso
                			}else {
                				contDosesEstadual += listaLotes.get(k).getQuantidade(); //total de doses vindas do governo estadual
                				contCustoEstadual += listaLotes.get(k).getCustoPorDose() *  listaLotes.get(k).getQuantidade(); //soma dos custos das doses estaduais com peso
                			}                         			
                			
                		}
                	}
                	if(contDosesFederal != 0) {
                		mediaFederal = contCustoFederal / contDosesFederal; //custo medio das doses entregues pelo governo federal
                	}
                	if(contDosesEstadual != 0) {
                		mediaEstadual = contCustoEstadual / contDosesEstadual; //custo medio das doses entregues pelo governo estadual
                	}
                }
            }
			/** Deletendo a ultima virgula depois da vacina/fabricante */
			conteudo = conteudo.substring(0,conteudo.length()-1) + conteudo.substring(conteudo.length());
			conteudo = conteudo.substring(0,conteudo.length()-1) + conteudo.substring(conteudo.length());
			ordenaDatas(listaDatas);
        	double totalDatas = 0;
        	long tempo1, tempo2;

        	for(int d = 1; d < listaDatas.size(); d++) {
        		tempo1 = listaDatas.get(d-1).getTime();
        		tempo2 = listaDatas.get(d).getTime();
        		totalDatas += (tempo2 - tempo1)/86400000;
        		
        	}
        	totalDatas = totalDatas / (listaDatas.size()-1);
        	listaDatas.clear();
			//System.out.println("Total de doses para essa doenca: " + contTotalDoses);
			conteudo += ";" + contTotalDoses;
        	//System.out.printf("Media custo Federal: %.2f\n", mediaFederal);
			float valorArredondado = Math.round( mediaFederal * 100f) / 100f;
        	conteudo += ";" + formatinho.format(valorArredondado);
        	//System.out.printf("Media custo Estadual: %.2f\n", mediaEstadual);
        	float valorArredondado2 = Math.round( mediaEstadual * 100f) / 100f;
        	conteudo += ";" + formatinho.format(valorArredondado2);
        	
        	/** Colocando media das datas */
        	conteudo += ";" + formatinho.format(totalDatas);
        	
        	
        	arqEscrita.escrita(nomeArquivo, conteudo);
        	contDosesFederal = 0;
        	contDosesEstadual = 0;
        	contCustoFederal = 0;
        	contCustoEstadual = 0;
        	contTotalDoses = 0;
        	mediaFederal = 0;
        	mediaEstadual = 0;
		}
    }
		
	public void ordenaVacina(ArrayList<Vacina> listaVacina) {
	    	Collections.sort(listaVacina, Comparator.comparing(Vacina::getNomeVacina));
	}
	
	public void ordenaDoenca(ArrayList<String> listaDoenca) {
		Collections.sort(listaDoenca);
	}
	
	public void ordenaDatas(ArrayList<Date> listaDatas) {
		Collections.sort(listaDatas);
	}

    @Override
    public String toString() {
        return vacina + ";" + ubs + ";" + quantidade + ";" + custoPorDose + ";" + fonte + ";" + data;
    }
}
