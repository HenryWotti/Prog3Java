package elementosDoDominio;

import java.util.ArrayList;

public class VacinaDoseUnica extends Vacina{
	
	public VacinaDoseUnica(){
	}

	public VacinaDoseUnica(String nomeVacina, String fabricante, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, fabricante, doenca, tipo, informacaoAdicional);
	}
	
	public VacinaDoseUnica(String nomeVacina, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, doenca, tipo, informacaoAdicional);
	}
}
