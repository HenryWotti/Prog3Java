package elementosDoDominio;

public class VacinaDoseDupla extends Vacina{
	protected String intervaloMin;
	protected String intervaloMax;
	
	public VacinaDoseDupla(){
		
	}

	public VacinaDoseDupla(String nomeVacina, String fabricante, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, fabricante, doenca, tipo, informacaoAdicional);
	}
	
	public VacinaDoseDupla(String nomeVacina, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, doenca, tipo, informacaoAdicional);
	}

	public String getIntervaloMin() {
		return intervaloMin;
	}

	public String getIntervaloMax() {
		return intervaloMax;
	}

	@Override
	public String getInformacoes(int opcao) {
		if(opcao == 1) {
			return intervaloMin;
		}
		else{
			return intervaloMax;
		}
	}

	@Override
	protected void relatorio3(Vacina vacinaAgendada) {
		System.out.println("Intervalos dose dupla:" );
		System.out.println(vacinaAgendada.getInformacoes(1) + "-" + vacinaAgendada.getInformacoes(2));
	}

//	@Override
//	public int retornaIntervaloMin() {
//		// TODO Auto-generated method stub
//		return intervaloMin;
//	}
//
//
//
//	@Override
//	public int retornaIntervaloMax() {
//		// TODO Auto-generated method stub
//		return intervaloMax;
//	}  
}