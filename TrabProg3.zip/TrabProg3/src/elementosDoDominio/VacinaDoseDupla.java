package elementosDoDominio;

import java.util.ArrayList;

public class VacinaDoseDupla extends Vacina{
	protected String intervaloMin;
	protected String intervaloMax;
	
	public VacinaDoseDupla(){
	}

	public VacinaDoseDupla(String nomeVacina, String fabricante, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, fabricante, doenca, tipo, informacaoAdicional);
	}
	
	public VacinaDoseDupla(String nomeVacina, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, doenca, tipo, informacaoAdicional);
	}

	public String getIntervaloMin() {
		return intervaloMin;
	}

	public String getIntervaloMax() {
		return intervaloMax;
	}
}