package elementosDoDominio;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class AgendarVacinacao implements Serializable {
	/** Essa classe é responsável por gerenciar os métodos de agendamento de vacinação,
	 * inclui status de cada agendamento e a situação da dose dupla quando aplicável*/
	private String operacao;
	private String cpf;
    private Date dataHora;
    private Ubs ubs;
    private Vacina vacinaAgendada;
    private String nome;
    private Date dataNascimento;
    private String matricula;
    private boolean statusAgendamento;
    private boolean statusEfetuado;
    protected boolean tomouSegundaDose;
    
    public void setTomouSegundaDose(boolean valor) {
		this.tomouSegundaDose = valor;
	}
	
	public boolean getTomouSegundaDose() {
		return tomouSegundaDose;
	}
	
    public AgendarVacinacao() {
    	
    }
    
    public AgendarVacinacao(String operacao, String cpf, Date dataHora, Ubs ubs, Vacina vac, String nome, Date dataNascimento, String matricula) {
        this.operacao = operacao;
        this.cpf = cpf;
    	this.dataHora = dataHora;
        this.ubs = ubs;
        this.vacinaAgendada = vac;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.cpf = cpf;
        this.matricula = matricula;
        this.statusAgendamento = true;
        this.statusEfetuado = false;
    }

    public int getIdade() {
        Calendar calendar = Calendar.getInstance();

        calendar.setTime(this.dataNascimento);
        int dateYear = calendar.get(Calendar.YEAR);
    	
        int idade = 2021 - dateYear;    			
    			
    	return idade;
    }
    
    public Vacina getVacinaAgendada() {
		return vacinaAgendada;
	}

	public Date getDataHora() {
        return this.dataHora;
    }

    public Ubs getUbs() {
        return this.ubs;
    }

    public String getNome() {
        return this.nome;
    }

    public Date getDataNascimento() {
        return this.dataNascimento;
    }

    public String getCpf() {
        return this.cpf;
    }

    public boolean getStatusAgendamento() {
        return this.statusAgendamento;
    }

    public boolean getStatusEfetuado() {
        return this.statusEfetuado;
    }

    public void cancela() {
        this.statusAgendamento = false;
    }

    public void efetuaVacinacao() {
        this.statusEfetuado = true;
    }

}
