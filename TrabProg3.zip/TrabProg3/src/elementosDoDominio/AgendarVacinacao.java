package elementosDoDominio;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class AgendarVacinacao implements Serializable {
	private String operacao;
	private String cpf;
    private Date dataHora;
    private Ubs ubs;
    private Vacina vacinaAgendada;
    private String nome;
    private Date dataNascimento;
    private String matricula;
    private boolean statusAgendamento;
    private boolean statusEfetuado;
    

    public AgendarVacinacao(String operacao, String cpf, Date dataHora, Ubs ubs, Vacina vac, String nome, Date dataNascimento, String matricula) {
        this.operacao = operacao;
        this.cpf = cpf;
    	this.dataHora = dataHora;
        this.ubs = ubs;
        this.vacinaAgendada = vac;
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        this.cpf = cpf;
        this.matricula = matricula;
        this.statusAgendamento = true;
        this.statusEfetuado = false;
    }

    public int getIdade() {
        Calendar calendar = Calendar.getInstance();

        calendar.setTime(this.dataNascimento);
        int dateYear = calendar.get(Calendar.YEAR);
    	
        int idade = 2021 - dateYear;    			
    			
    	return idade;
    }
    
    public Vacina getVacinaAgendada() {
		return vacinaAgendada;
	}

	public Date getDataHora() {
        return this.dataHora;
    }

    public Ubs getUbs() {
        return this.ubs;
    }

    public String getNome() {
        return this.nome;
    }

    public Date getDataNascimento() {
        return this.dataNascimento;
    }

    public String getCpf() {
        return this.cpf;
    }

    public boolean getStatusAgendamento() {
        return this.statusAgendamento;
    }

    public boolean getStatusEfetuado() {
        return this.statusEfetuado;
    }

    public void cancela() {
        this.statusAgendamento = false;
    }

    public void efetuaVacinacao() {
        this.statusEfetuado = true;
    }

    @Override
    public String toString() {
        return ubs + ";" + nome + ";" + cpf + ";" + "StatusAgendamento:" + statusAgendamento + ";" + "StatusEfetuado:"
                + statusEfetuado + ";" + dataHora + ";" + dataNascimento + ";"
                + printaStatus(statusEfetuado, statusAgendamento);
    }

    public String printaStatus(boolean statusEfetuado, boolean statusAgendado) {
        if (statusEfetuado == true) {
            return "Situação da Vacinação: Efetuada";
        } else if (statusEfetuado == false && statusAgendado == true) {
            return "Situação da Vacinação: Agendada";
        } else {
            return "Situação da Vacinação: Cancelada";
        }
    }

}
