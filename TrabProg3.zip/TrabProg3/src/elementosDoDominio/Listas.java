package elementosDoDominio;
import java.util.ArrayList;

public class Listas {
	ArrayList<Ubs> listaUbs = new ArrayList<Ubs>();
	ArrayList<Vacina> listaVacinas = new ArrayList<Vacina>();
	ArrayList<Lote> listaLotes = new ArrayList<Lote>();
	ArrayList<String> listaNomeDoencas = new ArrayList<String>();
    ArrayList<AgendarVacinacao> listaCidadaosAgendados = new ArrayList<AgendarVacinacao>();
    
     
    
    
}
