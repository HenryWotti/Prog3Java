package elementosDoDominio;

import java.util.ArrayList;

public class VacinaComEfeito extends Vacina{
	protected ArrayList<String> efeitosColaterais;
	
	public VacinaComEfeito(){
	}
	
	public VacinaComEfeito(String nomeVacina, String fabricante, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, fabricante, doenca, tipo, informacaoAdicional);
	}
	
	public VacinaComEfeito(String nomeVacina, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, doenca, tipo, informacaoAdicional);
	}

	public ArrayList<String> getEfeitosColaterais() {
		return efeitosColaterais;
	}
}
