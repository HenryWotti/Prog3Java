package elementosDoDominio;

import java.util.ArrayList;

public class VacinaComEfeito extends Vacina{
	protected ArrayList<String> efeitosColaterais;
	
	public VacinaComEfeito(){
		
	}
	
	public VacinaComEfeito(String nomeVacina, String fabricante, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, fabricante, doenca, tipo, informacaoAdicional);
	}
	
	public VacinaComEfeito(String nomeVacina, String doenca, String tipo, String informacaoAdicional) {
		super(nomeVacina, doenca, tipo, informacaoAdicional);
	}

	public ArrayList<String> getEfeitosColaterais() {
		return efeitosColaterais;
	}

	@Override
	public String getInformacoes(int opcao) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected void relatorio3(Vacina vacinaAgendada) {
		// TODO Auto-generated method stub
		
	}
}
