package interfaceUsuario;
import java.io.Serializable;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Scanner;

import elementosDoDominio.AgendarVacinacao;
import elementosDoDominio.Lote;
import elementosDoDominio.ServidorMunicipal;
import elementosDoDominio.Ubs;
import elementosDoDominio.Vacina;
import elementosDoDominio.VacinaComEfeito;
import elementosDoDominio.VacinaDoseDupla;
import elementosDoDominio.VacinaDoseUnica;
import entradaSaida.Arquivo;
import entradaSaida.Escritor;

import java.util.Map;
import java.util.HashMap;
import java.util.Locale;
import java.util.Date;
import java.util.Formatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;

public class Menu implements Serializable {

    Scanner scan = new Scanner(System.in);
    
    /** Declarando dois formatos diferentes, um pra data convencional e outro para data com hora */
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat formato2 = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    
    /** Colocando o locale.france temos a divisao dos numeros em casas decimais por virgula */
    NumberFormat formatinho = NumberFormat.getInstance(Locale.FRANCE);

    /** Conjuntos de Mapas e ArrayList auxiliares */
    Map<String, Ubs> mapaUbs = new HashMap<>();
    ArrayList<Ubs> listaUbs = new ArrayList<Ubs>();
    Map<String, ServidorMunicipal> mapaServidor = new HashMap<>();
    ArrayList<Lote> listaLotes = new ArrayList<Lote>();
    Map<String, Vacina> mapaVacina = new HashMap<>();
    Map<String, AgendarVacinacao> mapaAgendamento = new HashMap<>();
    ArrayList<String> listaNomeDoencas = new ArrayList<String>();
    ArrayList<Vacina> listaVacinas = new ArrayList<Vacina>();
    ArrayList<AgendarVacinacao> listaCidadaosVacinados = new ArrayList<AgendarVacinacao>();
    Map<Vacina, Lote> mapaLotes = new HashMap<>();
    
    /** Escritor utilizado para chamar as funções de serialização e desserialização*/
    Escritor escritor = new Escritor();
    
    /** Usado para chamar métodos declarados na classe Input (verificação de erros) */
    Inputs in = new Inputs();
    
    /** Arquivo no qual o erro será impresso caso haja */
    Arquivo arqErros = new Arquivo();
	String nomeArqErro = "output.txt";
	String erro;

    public void escolheMenu(int opcao, Arquivo arqLeitura) throws ParseException {
        switch (opcao) {
            case 1:
                /** Pegamos o arquivo com todas as Ubs e dividimos as ubs por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqUbs = arqLeitura.getArqUbs();
                String vetorUbs[] = arqUbs.split("\n");
                
                /** Agora com as UBSs divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada ubs separadamente, i começa com 1 para ignorar a primeira linha*/
                int i = 1;
                while(i < vetorUbs.length) {
                	String informacoesUbs[] = vetorUbs[i].split(";");
                	String sigla = informacoesUbs[0];
                	String nome = informacoesUbs[1];
                	
                	/** Verificando se está sendo cadastrada uma UBS repetida*/
                	Ubs testeUbs = mapaUbs.get(sigla);
                	boolean ubsRepetidaValidacao = in.verificaUBSrepetida(testeUbs);
                	try{
                		if(!ubsRepetidaValidacao)
                	        throw new Exception();
                	}
                	catch (Exception exception){
                		erro = "Cadastro repetido: " + sigla + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);        
                	}
                	/** Cadastrando UBS em uma mapa de UBSs e em uma Lista para ordenacao posterior */
                	Ubs ubs = new Ubs(nome, sigla);
                	mapaUbs.put(sigla, ubs);
                	listaUbs.add(ubs);
                	i++;
                }   
                break;

            case 2:
            	
            	/** Pegamos o arquivo com todas os Servidores e dividimos os servidores por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqServidor = arqLeitura.getArqServidor();
                String vetorServidor[] = arqServidor.split("\n");
                
                /** Agora com os Servidores divididos por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada servidor separadamente, j começa com 1 para ignorar a primeira linha*/
                String nomeServidor;
        		String matricula;
        		String dataServidor;
        		String ubsServidor;
        		Date data = null;
                int j = 1;
                while(j < vetorServidor.length) {
                	String informacoesServidor[] = vetorServidor[j].split(";");
                	/** Como data de nascimento não é uma informação obrigatória, devemos checar se está sendo entregue ou não*/
                	nomeServidor = informacoesServidor[0];
                	matricula = informacoesServidor[1];
                	dataServidor = informacoesServidor[2];
                	ubsServidor = informacoesServidor[3];
                		
                	/** Validacao da data informada, se for vazia quer dizer que nao há, se não for vazia e válida,
                	 *  já faz o parse de String para Date */
                	if(dataServidor != "") {
                		boolean dataValidacao = in.verificaData(dataServidor);
                		try{
                    		if(!dataValidacao) {
                    			throw new Exception();
                    		}else {
                                data = formato.parse(dataServidor);
                            }
                    	}
                    	catch (Exception exception){
                        	erro = "Dado inválido: " + dataServidor + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }
                	}
                	/** Verificando se a matricula informada é valida e a convertendo para int*/
                    boolean matValidacao = in.verificaEntradaNumerica(matricula);
                	try{
                		if(matValidacao == false) {
                			throw new Exception();
                		}  
                    }
                    catch (Exception exception){
                    	erro = "Dado inválido: " + matricula + ".";
                    	arqErros.escrita(nomeArqErro, erro);
                    	System.exit(1);       
                    }
                    /** Verificando se a matricula informada é repetida */
                    ServidorMunicipal testeMatricula = mapaServidor.get(matricula);
                    boolean matriculaRepetidaValidacao = in.verificaMatriculaServidorRepetido(testeMatricula);
                    try{
                		if(matriculaRepetidaValidacao == false) {
                			throw new Exception();
                		}  
                    }
                    catch (Exception exception){
                    	erro = "Cadastro repetido: " + matricula + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);
                    }
                    /** Busca e validacao da UBS informada, caso não haja nenhum problema, essa propria ubs será colocada
                     * no construtor */
                    Ubs testeUbsServidor = mapaUbs.get(ubsServidor);
                    boolean ubsValidacao1 = in.verificaUBS(testeUbsServidor);
                    try{
                		if(ubsValidacao1 == false) {
                			throw new Exception();
                		}  
                    }
                    catch (Exception exception){
                    	erro = "Referência inválida: " + ubsServidor + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);
                    }
                    /** Cadastrando Servidor em uma mapa de Servidores */
                    if(dataServidor != "") {
                    	ServidorMunicipal servidor = new ServidorMunicipal(nomeServidor, matricula, data, testeUbsServidor);
                        mapaServidor.put(matricula, servidor);
                    } else {
                    	ServidorMunicipal servidor = new ServidorMunicipal(nomeServidor, matricula, testeUbsServidor);
                        mapaServidor.put(matricula, servidor);
                    }
                	j++;
                }
                break;

            case 3:
            	
            	/** Pegamos o arquivo com todas as Vacinas e dividimos as vacinas por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqVacina = arqLeitura.getArqVacina();
                String vetorVacina[] = arqVacina.split("\n");
                
                /** Agora com as vacinas divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada vacina separadamente, k começa com 1 para ignorar a primeira linha*/
                int k = 1;
                while(k < vetorVacina.length) {
                	String informacoesVacinas[] = vetorVacina[k].split(";");
                	String nomeVacina = informacoesVacinas[0];
                	String fabricante = informacoesVacinas[1];
                	String doenca = informacoesVacinas[2];
                	String tipo = informacoesVacinas[3];
                	String infAdicional = informacoesVacinas[4];
                	
                	Vacina testeVacina = mapaVacina.get(nomeVacina);
                	boolean nomeVacRepetidoValidacao = in.verificaVacinaRepetida(testeVacina);
                	try{
                		if(nomeVacRepetidoValidacao == false) {
                			throw new Exception();
                		}  
                    }
                    catch (Exception exception){
                		erro = "Cadastro repetido: " + nomeVacina + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);
                	}
                	/** Verifica se o fabricante nao está vazio, então adiciona a vacina em uma mapa e em uma lista */
                	Vacina vacina;
                	if(fabricante.compareTo("") == 0) {
                		if(tipo.compareTo("D") == 0) {
                    		vacina = new VacinaDoseDupla(nomeVacina, doenca, tipo, infAdicional);
                    	}else if (tipo.compareTo("U") == 0) {
                    		vacina = new VacinaDoseUnica(nomeVacina, doenca, tipo, infAdicional);
                    	}else {
                    		vacina = new VacinaComEfeito(nomeVacina, doenca, tipo, infAdicional);
                    	}
                	}else {
                		if(tipo.compareTo("D") == 0) {
                    		vacina = new VacinaDoseDupla(nomeVacina, fabricante, doenca, tipo, infAdicional);
                    	}else if (tipo.compareTo("U") == 0) {
                    		vacina = new VacinaDoseUnica(nomeVacina, fabricante, doenca, tipo, infAdicional);
                    	}else {
                    		vacina = new VacinaComEfeito(nomeVacina, fabricante, doenca, tipo, infAdicional);
                    	}
                	}
                	mapaVacina.put(nomeVacina, vacina);
                	listaVacinas.add(vacina);
                	int cont = 0;
                	for(int n = 0; n<listaNomeDoencas.size(); n++) {
                		if(listaNomeDoencas.get(n).compareTo(doenca) == 0) {
                			cont++;
                		}
                	}
                	if(cont == 0) {
                		listaNomeDoencas.add(doenca);
                	}
                	k++;
                }   
                break;

            case 4:
            	
            	/** Pegamos o arquivo com todas os lotes e dividimos os lotes por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqLote = arqLeitura.getArqLote();
                String vetorLote[] = arqLote.split("\n");
                
                /** Agora com os Lotes divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada lote separadamente, l começa com 1 para ignorar a primeira linha*/
                int l = 1;
                while(l < vetorLote.length) {
                	String informacoesLote[] = vetorLote[l].split(";");
                	String nomeVacina = informacoesLote[0];
                	String siglaUbs = informacoesLote[1];
                	String dataEntrega = informacoesLote[2];
                	String quantidade = informacoesLote[3];
                	String custoPorDose = informacoesLote[4];
                	String fonte = informacoesLote[5];
                	Date data1 = null;
                	
                	/** Buscando no mapa e validando a vacina informada */
                	Vacina vacinaDoLote = mapaVacina.get(nomeVacina);
                	boolean vacinaValidacao1 = in.verificaVacina(vacinaDoLote);
                	try{
                		if(vacinaValidacao1 == false) {
                			throw new Exception();
                		}  
                    }
                    catch (Exception exception){
                		erro = "Referência inválida: " + nomeVacina + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);
                	}
                	/** Buscando no mapa e validando UBS informada */
                	Ubs ubsLote = mapaUbs.get(siglaUbs);
                	boolean ubsValidacao = in.verificaUBS(ubsLote);
                	try{
                		if(ubsValidacao == false) {
                			throw new Exception();
                		}
                    }
                    catch (Exception exception){
                		erro = "Referência inválida: " + siglaUbs + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);
                	}
                	/** Validacao da data informada se valida, já faz o parse */
                	boolean dataValidacao = in.verificaData(dataEntrega);
                	try{
                		if(!dataValidacao) {
                			throw new Exception();
                		}else {
                            data1 = formato.parse(dataEntrega);
                        }
                	}
                	catch (Exception exception){
                    	erro = "Dado inválido: " + dataEntrega + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);
                    }
                	/** Fazendo o parse da quantidade e custoPorDose */
                	int quantidadeInt = Integer.parseInt(quantidade);
                	double custoPorDoseDouble = (double) formatinho.parse(custoPorDose);
                	
                	/** Registrando lote e adicionando na lista e no mapa de lotes */
                	Lote lote = new Lote(vacinaDoLote, ubsLote, data1, quantidadeInt, custoPorDoseDouble, fonte);
                	listaLotes.add(lote);
                	mapaLotes.put(vacinaDoLote, lote);
                	l++;
                } 
                break;

            case 5:
            	
            	/** Pegamos o arquivo com todas os agendamentos e dividimos os agendamentos por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqAgendamento = arqLeitura.getArqAgendamento();
                String vetorAgendamento[] = arqAgendamento.split("\n");
                
                /** Agora com os Agendamentos divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada agendamento separadamente, m começa com 1 para ignorar a primeira linha*/
                int m = 1;
            	String dataHora="";
            	String siglaUbs="";
            	String nomeVacina="";
            	String nomeCidadao="";
            	String dataNascimento="";
            	String matriculaServidor="";
                while(m < vetorAgendamento.length) {
                	String informacoesAgendamento[] = vetorAgendamento[m].split(";");
                	/** Todos os 3 tipos de operação usam informacões de operacao e cpf */
                	String operacao = informacoesAgendamento[0];
                	String cpf = informacoesAgendamento[1];
                	/** Se a operacao for agendar, então precisamos ler mais informações*/
                	if(operacao.compareTo("A") == 0) {
                    	 dataHora = informacoesAgendamento[2];
                    	 siglaUbs = informacoesAgendamento[3];
                    	 nomeVacina = informacoesAgendamento[4];
                    	 nomeCidadao = informacoesAgendamento[5];
                    	 dataNascimento = informacoesAgendamento[6];
                    /** Se a operação for de efetuar, temos que saber a matricula do servidor que efetuou */
                	} else if(operacao.compareTo("R") == 0) {
                		matriculaServidor = informacoesAgendamento[7];
                	}
                	
                	
                	Date dataEHora = null;
                	Date dataDeNascimento = null;
                	Ubs ubsAgendamento = null;
                	Vacina vacinaAgendada = null;
                	/* Validando cpf */
                	boolean cpfValidacao = in.verificaEntradaNumerica(cpf);
                	try{
                		if(cpfValidacao == false) {
                			throw new Exception();
                		}
                    }
                    catch (Exception exception){
                		erro = "Dado inválido: " + cpf + ".";
                		arqErros.escrita(nomeArqErro, erro);
                		System.exit(1);
                	}
                	/** Validacao dos dados */
                	if(operacao.compareTo("A") == 0) {
                		boolean dataHoraValidacao = in.verificaDataEHora(dataHora);
                		try{
                    		if(dataHoraValidacao == false) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                        	erro = "Data hora inválida: " + dataHora + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }
                        dataEHora = formato2.parse(dataHora);
                        
                    	/* Encontrando e validando a ubs informada */
                    	ubsAgendamento = mapaUbs.get(siglaUbs);
                    	boolean ubsValidacao2 = in.verificaUBS(ubsAgendamento);
                    	try{
                    		if(ubsValidacao2 == false) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                    		erro = "Referência inválida: " + siglaUbs + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                    	}
                    	
                    	/* Validando data de nascimento */
                    	boolean nascimentoValidacao = in.verificaData(dataNascimento);
                    	try{
                    		if(!nascimentoValidacao) {
                    			throw new Exception();
                    		}else {
                    			dataDeNascimento = formato.parse(dataNascimento);
                            }
                    	}
                    	catch (Exception exception){
                    		erro = "Data nascimento inválida: " + dataNascimento + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }
                    	/** Verificando se é um agendamento de cpf repetido, fazemos menos menos no contaVacinados */
                    	AgendarVacinacao teste4 = mapaAgendamento.get(cpf);
                    	boolean agendamentoRepetidoValidacao = in.verificaAgendamentoRepetido(teste4);
                    	if(!agendamentoRepetidoValidacao) {
                    		/** Contamos vacinados por cpf, nao por dose */
                    		ubsAgendamento.decrementaVacinados();
                    	}
                    	/** Validando a vacina informada */
                    	vacinaAgendada = mapaVacina.get(nomeVacina);
                    	boolean vacinaValidacao = in.verificaVacina(vacinaAgendada);
                    	try{
                    		if(vacinaValidacao == false) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                    		erro = "Referência inválida: " + nomeVacina + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                    	}
                    	/** Caso seja o primeiro cadastro a ser realizado */
                    	if(ubsAgendamento.getAuxiliaAgendados() == 0) {
                    		ubsAgendamento.setPeriodoInicial(dataEHora);
                        	ubsAgendamento.setPeriodoFinal(dataEHora);
                        /** Atualizando o valor do periodo final e inicial */
                    	}else if (dataEHora.before(ubsAgendamento.getPeriodoInicial())){
                        		ubsAgendamento.setPeriodoInicial(dataEHora);
                        }else if (dataEHora.after(ubsAgendamento.getPeriodoFinal())){
                        		ubsAgendamento.setPeriodoFinal(dataEHora);
                        }
                    	/** Registro do agendamento no mapa de agendamento */
                    	AgendarVacinacao agendaVacina = new AgendarVacinacao(operacao, cpf, dataEHora, ubsAgendamento, vacinaAgendada, nomeCidadao, dataDeNascimento, matriculaServidor);
                    	agendaVacina.setTomouSegundaDose(false);
                    	/** Registra agendamentos no mapa e em uma lista */
                    	mapaAgendamento.put(cpf, agendaVacina);
                    	/** Já conta a quantidade de agendamento após verificar */
                    	ubsAgendamento.contaAgendados();
                    	ubsAgendamento.incrementaAuxiliar();
                    	
                	}else if(operacao.compareTo("C") == 0) {
                		/** Achar o agendamento pela chave cpf */
                		AgendarVacinacao agendamentoCancela = mapaAgendamento.get(cpf);
                		boolean agendamentoValidacao = in.verificaCPF(agendamentoCancela);
                		try{
                    		if(agendamentoValidacao == false) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                			erro = "Cidadao nao possui agendamento ativo: " + cpf + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                		}
                		Ubs ubsRegistrada = agendamentoCancela.getUbs();
                		ubsRegistrada.contaCancelados();
      
                		/** Método que cancela um agendamento. */
                		mapaAgendamento.remove(cpf);
                		agendamentoCancela.cancela();
                		/** Diminuindo o numero de agendamentos */
                		ubsRegistrada.decrementaAgendados();
                		ubsRegistrada.incrementaAuxiliar();
                		
                	} else if(operacao.compareTo("R") == 0){
                		/** Valida matricula */
                        ServidorMunicipal servidorM = mapaServidor.get(matriculaServidor);
                        try{
                    		if(servidorM == null) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                        	erro = "Servidor não encontrado.";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }                      
                        /** Acha o agendamento pelo cpf e valida */
                        AgendarVacinacao agendamentoEfetua = mapaAgendamento.get(cpf);
                        boolean efetuaValidacao = in.verificaCPF(agendamentoEfetua);
                        try{
                    		if(efetuaValidacao == false) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                        	erro = "Cidadao nao possui agendamento ativo: " + cpf + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }
                        /** Pega a ubs para aumentar o numero de vacinados */
                        Ubs ubsRegistrad = agendamentoEfetua.getUbs();
                        ubsRegistrad.contaVacinados();

                        /** Verifica se a Ubs recebeu lote da vacina requerida */
                        Vacina vacinaEfetuada = agendamentoEfetua.getVacinaAgendada();
                        Lote loteDaVac = mapaLotes.get(vacinaEfetuada);
                        try{
                    		if(loteDaVac == null) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                        	erro = ubsRegistrad.getNome() + " nao possui a vacina " + vacinaEfetuada.getNomeVacina() + " (" + vacinaEfetuada.getDoenca() + ") em estoque em " + agendamentoEfetua.getDataHora() + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }
                        
                        Ubs ubsDaVac = loteDaVac.getUbs();
                        boolean vacinaNaUbs = in.verificaVacinaNaUbs(ubsDaVac, ubsRegistrad);
                        try{
                    		if(vacinaNaUbs == false) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                        	erro = ubsRegistrad.getNome() + " nao possui a vacina " + vacinaEfetuada.getNomeVacina() + " (" + vacinaEfetuada.getDoenca() + ") em estoque em " + agendamentoEfetua.getDataHora() + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }
                        /** Pegamos a ubs do servidor informado pela matricula */
                        Ubs ubsServidor2 = servidorM.getUbs();
                        boolean ubsServidorValidacao = in.verificaUbsDoServidor(ubsServidor2, agendamentoEfetua.getUbs());
                        try{
                    		if(ubsServidorValidacao == false) {
                    			throw new Exception();
                    		}
                        }
                        catch (Exception exception){
                        	erro = "Servidor " + servidorM.getNomeCompleto() + "(Matricula: " + matriculaServidor + ") nao esta lotado na " + agendamentoEfetua.getUbs().getNome() + ".";
                    		arqErros.escrita(nomeArqErro, erro);
                    		System.exit(1);
                        }
                        
                        /** Metodo que efetua a vacinacao */
                        agendamentoEfetua.efetuaVacinacao();
                        /** Gravar numero de vacinas efetuadasDiminuindo o numero de agendamentos */
                        ubsRegistrad.decrementaAgendados();
                        ubsRegistrad.incrementaAuxiliar();
                        int n;
                        /** Nesse for verificamos se é a segunda dose do cidadao*/
                        for(n = 0; n < listaCidadaosVacinados.size(); n++) {
                        	if(agendamentoEfetua.getNome().compareTo(listaCidadaosVacinados.get(n).getNome()) == 0){
                        		listaCidadaosVacinados.get(n).setTomouSegundaDose(true);
                        		break;
                        	}
                        }
                        /** Caso nao tenha sido, adicionamos o cidadao na lista de vacinados*/
                        if(n == listaCidadaosVacinados.size()) {
                        	listaCidadaosVacinados.add(agendamentoEfetua);
                        }
                	}
                	m++;
                }   
                break;
                
            case 6:
            	/** Relatorio 1 : Vacinacao por UBS */
            	ordenaUbs(listaUbs);
            	String conteudo = "UBS;Vacinados;A Vacinar;Agendamentos Cancelados;Período";
            	String stringUbs;
            	Arquivo arqEscrita = new Arquivo();
            	String nomeArquivo = "1-vacinacao.csv";
            	//arqEscrita.escrita(nomeArquivo, "UBS;Vacinados;A Vacinar;Agendamentos Cancelados;Período\n");
            	for(int w = 0; w<listaUbs.size(); w++) {
            		/** Se a ubs não tiver agendamento, imprimir um traço na ultima coluna */
            		if(listaUbs.get(w).getAuxiliaAgendados() == 0) {
            			conteudo += "\n" + listaUbs.get(w).getNome() + ";;;;-";
            		}
            		conteudo += "\n" + listaUbs.get(w).toString();
            	}
            	arqEscrita.escrita(nomeArquivo, conteudo);
            	
            	
            	/** Relatorio 2: Entregas de vacina por Doença*/	
            	Lote loteRelatorio = new Lote();
            	loteRelatorio.relatorio2(listaVacinas, listaNomeDoencas, listaLotes);
            		
            	/** Relatorio 3: Comunicados aos cidadão vacinados*/
            	String conteudo3 = "Cidadão;CPF;Idade;Comunicado\n";
            	Arquivo arqEscrita3 = new Arquivo();
            	String nomeArquivo3 = "3-comunicados.csv";
            	
            	for(int g = 0; g < listaCidadaosVacinados.size(); g++) {
            	}
            	ordenaCidadaos(listaCidadaosVacinados);
            	for(int y = 0; y < listaCidadaosVacinados.size(); y++) {
            		
            		conteudo3 += listaCidadaosVacinados.get(y).getNome() + ";"
            				+ embelezaCpf(listaCidadaosVacinados.get(y).getCpf()) + ";"
            				+ listaCidadaosVacinados.get(y).getIdade() + ";";
            		
            		if(listaCidadaosVacinados.get(y).getVacinaAgendada().getTipo().compareTo("U") == 0){
            			
            			conteudo3 += "Atenção, de acordo com o estudo disponível em "
            					+ listaCidadaosVacinados.get(y).getVacinaAgendada().getInformacaoAdicional()
            					+ ", não é necessária uma segunda dose da vacina "
            					+ listaCidadaosVacinados.get(y).getVacinaAgendada().getNomeVacina() + "!\n";
            			
            		} else if(listaCidadaosVacinados.get(y).getVacinaAgendada().getTipo().compareTo("E") == 0) {
            			
            			conteudo3 += "Atenção aos possíveis efeitos colaterais da vacina "
            					+ listaCidadaosVacinados.get(y).getVacinaAgendada().getNomeVacina()
            					+ ": "
            					+ listaCidadaosVacinados.get(y).getVacinaAgendada().getInformacaoAdicional()
            					+ ". Se persistirem, procure a UBS.\n";
            			
            		}else if(listaCidadaosVacinados.get(y).getVacinaAgendada().getTipo().compareTo("D") == 0){
            			if(listaCidadaosVacinados.get(y).getTomouSegundaDose() == true) {
            				
            				conteudo3 += "Parabéns, você já tomou as duas doses da vacina "
            						+ listaCidadaosVacinados.get(y).getVacinaAgendada().getNomeVacina() + "!\n";
            				
            			}else {
            				String intervalos[] = listaCidadaosVacinados.get(y).getVacinaAgendada().getInformacaoAdicional().split("-");
            				int intervaloMin = Integer.parseInt(intervalos[0]);
            				int intervaloMax = Integer.parseInt(intervalos[1]);
            				
            				/** Calculando o intervalo para a proxima dose */
            				Calendar min = Calendar.getInstance(); 
            				min.setTime(listaCidadaosVacinados.get(y).getDataHora()); 
            				min.add(Calendar.DATE, intervaloMin);
            				
            				Calendar max = Calendar.getInstance();
            				max.setTime(listaCidadaosVacinados.get(y).getDataHora());
            				max.add(Calendar.DATE, intervaloMax);
            				
            				conteudo3 += "Fique atento, você deve agendar para tomar a segunda dose da vacina "
            						+ listaCidadaosVacinados.get(y).getVacinaAgendada().getNomeVacina() 
            						+ " entre os dias " + formato.format(min.getTime()) 
            						+ " e "
            						+ formato.format(max.getTime()) + ".\n";
            				
            			}
            		}
            	}
            	/** Deletendo o ultimo \n */
    			conteudo3 = conteudo3.substring(0,conteudo3.length()-1) + conteudo3.substring(conteudo3.length());
            	arqEscrita3.escrita(nomeArquivo3, conteudo3);
            	
            	break; //break do menu principal case 6
            case 7:
            	/** Adicionaremos todos os dados que temos salvos nesse Array List */
            	ArrayList<Object> dados = new ArrayList<Object>();
            	dados.add(listaUbs);
            	dados.add(listaLotes);
            	dados.add(listaNomeDoencas);
            	dados.add(listaVacinas);
            	dados.add(listaCidadaosVacinados);
            	
            	escritor.serializar(dados);
            	
            	break;
            case 8:
             	ArrayList<Object> dadosD = escritor.desserializar();
             	
             	listaUbs = (ArrayList<Ubs>) dadosD.get(0);
             	listaLotes = (ArrayList<Lote>) dadosD.get(1);
             	listaNomeDoencas = (ArrayList<String>) dadosD.get(2);
             	listaVacinas = (ArrayList<Vacina>) dadosD.get(3);
             	listaCidadaosVacinados = (ArrayList<AgendarVacinacao>) dadosD.get(4);
             	
            	break;
            default:
                break;
        }
    }

	public void ordenaUbs(ArrayList<Ubs> listaUbs) {
    	Collections.sort(listaUbs, Comparator.comparing(Ubs::getAuxiliaAgendados).reversed().thenComparing(Ubs::getSigla));
    }
    
    public void ordenaCidadaos(ArrayList<AgendarVacinacao> listaCidadaosVacinados) {
    	Collections.sort(listaCidadaosVacinados, Comparator.comparing(AgendarVacinacao::getNome).reversed());
    }
    
    public String embelezaCpf(String cpf) {
    	String cpfBelo = "";
    	
    	cpfBelo += cpf.charAt(0);
    	cpfBelo += cpf.charAt(1);
    	cpfBelo += cpf.charAt(2);
    	cpfBelo += ".";
    	cpfBelo += cpf.charAt(3);
    	cpfBelo += cpf.charAt(4);
    	cpfBelo += cpf.charAt(5);
    	cpfBelo += ".";
    	cpfBelo += cpf.charAt(6);
    	cpfBelo += cpf.charAt(7);
    	cpfBelo += cpf.charAt(8);
    	cpfBelo += "-";
    	cpfBelo += cpf.charAt(9);
    	cpfBelo += cpf.charAt(10);
    	
    	return cpfBelo;
    } 
}