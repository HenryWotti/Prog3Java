package interfaceUsuario;
import java.io.Serializable;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import elementosDoDominio.AgendarVacinacao;
import elementosDoDominio.Lote;
import elementosDoDominio.ServidorMunicipal;
import elementosDoDominio.Ubs;
import elementosDoDominio.Vacina;
import elementosDoDominio.VacinaComEfeito;
import elementosDoDominio.VacinaDoseDupla;
import elementosDoDominio.VacinaDoseUnica;
import entradaSaida.Arquivo;

import java.util.Map;
import java.util.HashMap;
import java.util.Locale;
import java.util.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Menu implements Serializable {

    Scanner scan = new Scanner(System.in);
    
    /** Declarando dois formatos diferentes, um pra data convencional e outro para data com hora */
    SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat formato2 = new SimpleDateFormat("dd/MM/yyyy HH:mm");
    
    NumberFormat format = NumberFormat.getInstance(Locale.FRANCE);

    /** Conjuntos de Mapas e ArrayList auxiliares */
    Map<String, Ubs> mapaUbs = new HashMap<>();
    ArrayList<Ubs> listaUbs = new ArrayList<Ubs>();
    Map<String, ServidorMunicipal> mapaServidor = new HashMap<>();
    ArrayList<Lote> listaLotes = new ArrayList<Lote>();
    Map<String, Vacina> mapaVacina = new HashMap<>();
    Map<String, AgendarVacinacao> mapaAgendamento = new HashMap<>();
    ArrayList<String> listaNomeDoencas = new ArrayList<String>();
    ArrayList<Vacina> listaVacinas = new ArrayList<Vacina>();
    ArrayList<AgendarVacinacao> listaCidadaosAgendados = new ArrayList<AgendarVacinacao>();
    Map<Vacina, Lote> mapaLotes = new HashMap<>();
    
    /** String utilizada para ler o lixo após a leitura de um número */
    String lixo;
    
    /** Usado para chamar métodos declarados na classe Input */
    Inputs in = new Inputs();

    public void escolheMenu(int opcao, Arquivo arqLeitura) throws ParseException {
        switch (opcao) {
            case 1:
            	
                /** Pegamos o arquivo com todas as Ubs e dividimos as ubs por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqUbs = arqLeitura.getArqUbs();
                String vetorUbs[] = arqUbs.split("\n");
                
                /** Agora com as UBSs divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada ubs separadamente, i começa com 1 para ignorar a primeira linha*/
                int i = 1;
                while(i < vetorUbs.length) {
                	String informacoesUbs[] = vetorUbs[i].split(";");
                	String sigla = informacoesUbs[0];
                	String nome = informacoesUbs[1];
                	
                	/** Verificando se está sendo cadastrada uma UBS repetida*/
                	Ubs testeUbs = mapaUbs.get(sigla);
                	boolean ubsRepetidaValidacao = in.verificaUBSrepetida(testeUbs);
                	if(!ubsRepetidaValidacao) {
                		System.out.println("Cadastro repetido: " + sigla);
                		break;
                	}
                	/** Cadastrando UBS em uma mapa de UBSs e em uma Lista para ordenacao posterior */
                	Ubs ubs = new Ubs(nome, sigla);
                	mapaUbs.put(sigla, ubs);
                	listaUbs.add(ubs);
                	i++;
                }   
                break;

            case 2:
            	
            	/** Pegamos o arquivo com todas os Servidores e dividimos os servidores por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqServidor = arqLeitura.getArqServidor();
                String vetorServidor[] = arqServidor.split("\n");
                
                /** Agora com os Servidores divididos por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada servidor separadamente, j começa com 1 para ignorar a primeira linha*/
                String nomeServidor;
        		String matricula;
        		String dataServidor;
        		String ubsServidor;
        		Date data = null;
                int j = 1;
                while(j < vetorServidor.length) {
                	String informacoesServidor[] = vetorServidor[j].split(";");
                	/** Como data de nascimento não é uma informação obrigatória, devemos checar se está sendo entregue ou não*/
                	nomeServidor = informacoesServidor[0];
                	matricula = informacoesServidor[1];
                	dataServidor = informacoesServidor[2];
                	ubsServidor = informacoesServidor[3];
                		
                	/** Validacao da data informada, se for vazia quer dizer que nao há, se não for vazia e válida,
                	 *  já faz o parse de String para Date */
                	if(dataServidor != "") {
                		boolean dataValidacao = in.verificaData(dataServidor);
                        if(!dataValidacao) {
                        	System.out.println(j + "Dado inválido: " + dataServidor);
                        	break;
                        }
                        else {
                            data = formato.parse(dataServidor);
                        }
                	}
                	/** Verificando se a matricula informada é valida e a convertendo para int*/
                    boolean matValidacao = in.verificaEntradaNumerica(matricula);
                    if(matValidacao == false) {
                    	System.out.println("Dado inválido: " + matricula);
                    	break;
                    }
                    /** Verificando se a matricula informada é repetida */
                    ServidorMunicipal testeMatricula = mapaServidor.get(matricula);
                    boolean matriculaRepetidaValidacao = in.verificaMatriculaServidorRepetido(testeMatricula);
                    if(!matriculaRepetidaValidacao) {
                    	System.out.println("Cadastro repetido: " + matricula);
                    	break;
                    }
                    /** Busca e validacao da UBS informada, caso não haja nenhum problema, essa propria ubs será colocada
                     * no construtor */
                    Ubs testeUbsServidor = mapaUbs.get(ubsServidor);
                    boolean ubsValidacao1 = in.verificaUBS(testeUbsServidor);
                    if(!ubsValidacao1) {
                    	System.out.println("Referência inválida: " + ubsServidor);
                    	break;
                    }
                    /** Cadastrando Servidor em uma mapa de Servidores */
                    if(dataServidor != "") {
                    	ServidorMunicipal servidor = new ServidorMunicipal(nomeServidor, matricula, data, testeUbsServidor);
                        mapaServidor.put(matricula, servidor);
                    } else {
                    	ServidorMunicipal servidor = new ServidorMunicipal(nomeServidor, matricula, testeUbsServidor);
                        mapaServidor.put(matricula, servidor);
                    }
                	j++;
                }
                break;

            case 3:
            	
            	/** Pegamos o arquivo com todas as Vacinas e dividimos as vacinas por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqVacina = arqLeitura.getArqVacina();
                String vetorVacina[] = arqVacina.split("\n");
                
                /** Agora com as vacinas divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada vacina separadamente, k começa com 1 para ignorar a primeira linha*/
                int k = 1;
                while(k < vetorVacina.length) {
                	String informacoesVacinas[] = vetorVacina[k].split(";");
                	String nomeVacina = informacoesVacinas[0];
                	String fabricante = informacoesVacinas[1];
                	String doenca = informacoesVacinas[2];
                	String tipo = informacoesVacinas[3];
                	String infAdicional = informacoesVacinas[4];
                	
                	Vacina testeVacina = mapaVacina.get(nomeVacina);
                	boolean nomeVacRepetidoValidacao = in.verificaVacinaRepetida(testeVacina);
                	if(!nomeVacRepetidoValidacao) {
                		System.out.println("Cadastro repetido: " + nomeVacina);
                		break;
                	}
                	/** Verifica se o fabricante nao está vazio, então adiciona a vacina em uma mapa e em uma lista */
                	Vacina vacina;
                	if(fabricante != "") {
                		if(tipo == "D") {
                    		vacina = new VacinaDoseDupla(nomeVacina, doenca, tipo, infAdicional);
                    	}else if (tipo == "U") {
                    		vacina = new VacinaDoseUnica(nomeVacina, doenca, tipo, infAdicional);
                    	}else {
                    		vacina = new VacinaComEfeito(nomeVacina, doenca, tipo, infAdicional);
                    	}
                	}else {
                		if(tipo == "D") {
                    		vacina = new VacinaDoseDupla(nomeVacina, fabricante, doenca, tipo, infAdicional);
                    	}else if (tipo == "U") {
                    		vacina = new VacinaDoseUnica(nomeVacina, fabricante, doenca, tipo, infAdicional);
                    	}else {
                    		vacina = new VacinaComEfeito(nomeVacina, fabricante, doenca, tipo, infAdicional);
                    	}
                	}
                	mapaVacina.put(nomeVacina, vacina);
                	listaVacinas.add(vacina);
                	k++;
                }   
                break;

            case 4:
            	
            	/** Pegamos o arquivo com todas os lotes e dividimos os lotes por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqLote = arqLeitura.getArqLote();
                String vetorLote[] = arqLote.split("\n");
                
                /** Agora com os Lotes divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada lote separadamente, l começa com 1 para ignorar a primeira linha*/
                int l = 1;
                while(l < vetorLote.length) {
                	String informacoesLote[] = vetorLote[l].split(";");
                	String nomeVacina = informacoesLote[0];
                	String siglaUbs = informacoesLote[1];
                	String dataEntrega = informacoesLote[2];
                	String quantidade = informacoesLote[3];
                	String custoPorDose = informacoesLote[4];
                	String fonte = informacoesLote[5];
                	Date data1;
                	
                	/** Buscando no mapa e validando a vacina informada */
                	Vacina vacinaDoLote = mapaVacina.get(nomeVacina);
                	boolean vacinaValidacao1 = in.verificaVacina(vacinaDoLote);
                	if(!vacinaValidacao1) {
                		System.out.println("Referência inválida: " + nomeVacina);
                		break;
                	}
                	/** Buscando no mapa e validando UBS informada */
                	Ubs ubsLote = mapaUbs.get(siglaUbs);
                	boolean ubsValidacao = in.verificaUBS(ubsLote);
                	if(!ubsValidacao) {
                		System.out.println("Referência inválida: " + siglaUbs);
                		break;
                	}
                	/** Validacao da data informada se valida, já faz o parse */
                	boolean dataValidacao = in.verificaData(dataEntrega);
                	if(!dataValidacao) {
                		System.out.println("Data inválida: " + dataEntrega);
                		break;
                	}else {
                		data1 = formato.parse(dataEntrega);
                	}
                	/** Fazendo o parse da quantidade e custoPorDose */
                	int quantidadeInt = Integer.parseInt(quantidade);
                	double custoPorDoseDouble = (double) format.parse(custoPorDose);
                	
                	/** Registrando lote e adicionando na lista e no mapa de lotes */
                	Lote lote = new Lote(vacinaDoLote, ubsLote, data1, quantidadeInt, custoPorDoseDouble, fonte);
                	listaLotes.add(lote);
                	mapaLotes.put(vacinaDoLote, lote);
                	l++;
                }   
                break;

            case 5:
            	
            	/** Pegamos o arquivo com todas os agendamentos e dividimos os agendamentos por linha, usando o metodo split.
                 * Sempre iremos ignorar a primeira linha do arquivo, pois se trata de uma legenda informativa. */
                String arqAgendamento = arqLeitura.getArqAgendamento();
                String vetorAgendamento[] = arqAgendamento.split("\n");
                
                /** Agora com os Agendamentos divididas por linhas, iremos dividir cada linha por ponto e virgula, pra pegar
                 * as informações de cada agendamento separadamente, m começa com 1 para ignorar a primeira linha*/
                int m = 1;
                while(m < vetorAgendamento.length) {
                	String informacoesLote[] = vetorAgendamento[m].split(";");
                	String operacao = informacoesLote[0];
                	String cpf = informacoesLote[1];
                	String dataHora = informacoesLote[2];
                	String siglaUbs = informacoesLote[3];
                	String nomeVacina = informacoesLote[4];
                	String nomeCidadao = informacoesLote[5];
                	String dataNascimento = informacoesLote[6];
                	String matriculaServidor = informacoesLote[7];
                	Date dataEHora;
                	Date dataDeNascimento;
                	
                	/** Validacao dos dados */
                	boolean dataHoraValidacao = in.verificaDataEHora(dataHora);
                	if(!dataHoraValidacao) {
                		System.out.println("Data inválida: " + dataHora);
                		break;
                	}else {
                		dataEHora = formato.parse(dataHora);
                	}
                	/* Encontrando e validando a ubs informada */
                	Ubs ubsAgendamento = mapaUbs.get(siglaUbs);
                	boolean ubsValidacao2 = in.verificaUBS(ubsAgendamento);
                	if(!ubsValidacao2) {
                		System.out.println("Referência inválida: " + siglaUbs);
                		break;
                	}
                	/** Já conta a quantidade de agendamento após verificar */
                	ubsAgendamento.contaAgendados();
                	/* Validando data de nascimento */
                	boolean nascimentoValidacao = in.verificaData(dataNascimento);
                	if(!nascimentoValidacao) {
                		System.out.println("Data inválida: " + dataNascimento);
                		break;
                	}else {
                		dataDeNascimento = formato.parse(dataNascimento);
                	}
                	/* Validando cpf */
                	boolean cpfValidacao = in.verificaEntradaNumerica(cpf);
                	if(cpfValidacao == false) {
                		System.out.println("Dado inválido: " + cpf);
                		break;
                	}
                	/** Verificando se é um agendamento repetido */
                	AgendarVacinacao teste4 = mapaAgendamento.get(cpf);
                	boolean agendamentoRepetidoValidacao = in.verificaAgendamentoRepetido(teste4);
                	if(!agendamentoRepetidoValidacao) {
                		System.out.println("Cadastro repetido: " + cpf);
                		break;
                	}
                	/** Validando a vacina informada */
                	Vacina vacinaAgendada = mapaVacina.get(nomeVacina);
                	boolean vacinaValidacao = in.verificaVacina(vacinaAgendada);
                	if(!vacinaValidacao) {
                		System.out.println("Referência inválida: " + nomeVacina);
                		break;
                	}
                	/** Caso seja o primeiro cadastro a ser realizado */
                	if(mapaAgendamento == null) { 
                    	ubsAgendamento.setPeriodoInicial(dataEHora);
                    	ubsAgendamento.setPeriodoFinal(dataEHora);
                    }
                	
                	/**--------------------------COMPARAR PERIODO INICIAL E FINAL PRA SUBSTITUIR COM OS QUE VEM AI--------------------------*/
                	/**--------------------------REALIZAR AS OPERACOES DE ACORDO COM O TIPO DE OPERACAO RECEBIDA--------------------------*/
                	
                	/** Registro do agendamento no mapa de agendamento */
                	AgendarVacinacao agendaVacina = new AgendarVacinacao(operacao, cpf, dataEHora, ubsAgendamento, vacinaAgendada, nomeCidadao, dataDeNascimento, matriculaServidor);
                	/** Registra agendamentos no mapa e em uma lista */
                	mapaAgendamento.put(cpf, agendaVacina);
                	listaCidadaosAgendados.add(agendaVacina);
                	m++;
                }   
                break;

            case 6:
                System.out.println("Agendamentos até agora:");
                for (Map.Entry<String, AgendarVacinacao> entry : mapaAgendamento.entrySet()) {
                    System.out.println(entry.getValue());
                }
                System.out.println("Digite o CPF");
                String cpf2; // chave para achar o agendamento

                cpf2 = scan.nextLine();    

                boolean cpf2Validacao = in.verificaEntradaNumerica(cpf2);
                if(cpf2Validacao == false) {
                	System.out.println("Dado inválido: " + cpf2);
                	break;
                }
                
                // achar o agendamento pela chave cpf
                AgendarVacinacao agendamentoCancela = mapaAgendamento.get(cpf2);
                boolean agendamentoValidacao = in.verificaCPF(agendamentoCancela);
                if(!agendamentoValidacao) {
                	System.out.println("Cidadao nao possui agendamento ativo: " + cpf2);
                	break;
                }
                
                Ubs ubsRegistrada = agendamentoCancela.getUbs();
                ubsRegistrada.contaCancelados();

                // método que cancela um agendamento.
                agendamentoCancela.cancela();

                break;

            case 7:
                System.out.println("Agendamentos até agora:");
                for (Map.Entry<String, AgendarVacinacao> entry : mapaAgendamento.entrySet()) {
                    System.out.println(entry.getValue());
                }
                System.out.println("Digite o CPF e a MATRICULA do servidor");
                String cpf3;
                String matricula3;

                cpf3 = scan.nextLine();
                boolean cpf3Validacao = in.verificaEntradaNumerica(cpf3);
                if(cpf3Validacao == false) {
                	System.out.println("Dado inválido: " + cpf3);
                	break;
                }
                
                matricula3 = scan.nextLine(); 
                ServidorMunicipal servidorM = mapaServidor.get(matricula3);
                if(servidorM == null) {
                	System.out.println("Servidor não encontrado");
                }
                                             
                // achar o agendamento pelo cpf e validar
                AgendarVacinacao agendamentoEfetua = mapaAgendamento.get(cpf3);
                boolean efetuaValidacao = in.verificaCPF(agendamentoEfetua);
                if(!efetuaValidacao) {
                	System.out.println("Cidadao nao possui agendamento ativo: " + cpf3);
                	break;
                }
                
                Ubs ubsRegistrad = agendamentoEfetua.getUbs();
                ubsRegistrad.contaVacinados();

                //verificar melhor depois, mapa é o ideal? fica a indagação
                Vacina vacinaEfetuada = agendamentoEfetua.getVacinaAgendada();
                Lote loteDaVac = mapaLotes.get(vacinaEfetuada);
                if(loteDaVac == null) {
                	System.out.println(ubsRegistrad.getNome() + " nao possui a vacina " + vacinaEfetuada.getNomeVacina() + " (" + vacinaEfetuada.getDoenca() + ") em estoque em " + agendamentoEfetua.getDataHora());
                	break;
                }
                Ubs ubsDaVac = loteDaVac.getUbs();
                
                boolean vacinaNaUbs = in.verificaVacinaNaUbs(ubsDaVac, ubsRegistrad);
                if(!vacinaNaUbs) {
                	System.out.println(ubsRegistrad.getNome() + " nao possui a vacina " + vacinaEfetuada.getNomeVacina() + " (" + vacinaEfetuada.getDoenca() + ") em estoque em " + agendamentoEfetua.getDataHora());
                	break;
                }
                //pegamos a ubs que o servidor informado pela matricula trabalha
                Ubs ubsServidor2 = servidorM.getUbs();
                boolean ubsServidorValidacao = in.verificaUbsDoServidor(ubsServidor2, agendamentoEfetua.getUbs());
                if(!ubsServidorValidacao) {
                	System.out.println("Servidor " + servidorM.getNomeCompleto() + "(Matricula: " + matricula3 + ") nao esta lotado na " + agendamentoEfetua.getUbs().getNome() + ".");
                	break;
                }
                
                // registra agendamento como vacinacao efetuada
                agendamentoEfetua.efetuaVacinacao();

                break;

            case 8:
            	System.out.println("Relatorio");
            	System.out.println("Qual relatório gostaria que fosse exibido?");
            	System.out.println("1 - Vacinação por UBS");
            	System.out.println("2 - Entregas de Vacina por Doença");
            	System.out.println("3 - Comunicados aos cidadão vacinados");
            	
            	
            	int option = scan.nextInt();
                lixo = scan.nextLine();
            	switch(option) {
            	case 1: 
            		System.out.println("Vacinação por UBS");
            		for (Map.Entry<String, Ubs> entry : mapaUbs.entrySet()) {
                        System.out.println(entry.getValue());
                        System.out.println();
                    }
            		ordenaUbs(listaUbs);
            		System.out.println(listaUbs);
            		
            		break;
            	case 2:
            		Lote loteRelatorio = new Lote();
            		loteRelatorio.relatorio2(listaVacinas, listaNomeDoencas, listaLotes);
            		
            		break;
            	case 3:
//            		System.out.println("Comunicados aos cidadão vacinados");
//            		
//            		
//            		for(int i = 0; i < listaCidadaosAgendados.size(); i++) {
//            			System.out.println("Nome:" + listaCidadaosAgendados.get(i).getNome());
//            			System.out.println("Idade:" + listaCidadaosAgendados.get(i).getIdade());
//
//            			//verificando se a vacina é dose única ou não
//            			if(listaCidadaosAgendados.get(i).getVacinaAgendada().getInformacoes(0) != null) {
//            				Vacina vacinaUnicaRelatorio = new VacinaDoseUnica();
//            				vacinaUnicaRelatorio.relatorio3(listaCidadaosAgendados.get(i).getVacinaAgendada());
//            				
//            				/**------- Pendente -------*/
//            			}else if(listaCidadaosAgendados.get(i).getVacinaAgendada().getEfeitosColaterais() != null) { //verificando se é vacina de efeitos colaterais
//            				Vacina vacinaEfeitoRelatorio = new VacinaComEfeito();
//            				for(int j = 0; j < listaCidadaosAgendados.get(i).getVacinaAgendada().getEfeitosColaterais().size(); j++){
//            					System.out.println(listaCidadaosAgendados.get(i).getVacinaAgendada().getEfeitosColaterais().get(j));
//            					vacinaEfeitoRelatorio.relatorio3(listaCidadaosAgendados.get(i).getVacinaAgendada());
//            				}
//            			}
//            			else{ //caso seja dose dupla
//            				Vacina vacinaDoseDupla = new VacinaDoseDupla();
//            				vacinaDoseDupla.relatorio3(listaCidadaosAgendados.get(i).getVacinaAgendada());
//            			}  			
//            		}
//            		break;
            	default:
            		break;
            	}
            	break; //break do menu principal case 8
            case 9:
//            	System.out.println("Salvar");
//            	System.out.println("Informe o nome do arquivo");
//            	nomeArq = scan.nextLine();
//            	Escritor escritor = new Escritor();
//            	escritor.escritor(nomeArq);
//            	escritor.serializar(listaUbs);
            	// Serializa um objeto no formato binário em um arquivo
            	  // armazenado no local do segundo parâmetro
            	  
            	//saveObject(vacina, nomeArq);

            	
            	break;
            case 10:
//            	System.out.println("Carregando...");
//            	Escritor escritor2 = new Escritor();
//            	System.out.println("Informe o nome do arquivo");
//            	nomeArq = scan.nextLine();
//            	escritor2.escritor(nomeArq);
//            	ArrayList<Ubs> listaUbsDescarregada = new ArrayList<Ubs>();
//            	listaUbsDescarregada = escritor2.desserializar();
//            	listaUbs.addAll(listaUbsDescarregada);
            	
            	break;
            case 11: //encerra programa
            	break;

            default:
                break;
        }
    }

	public void ordenaUbs(ArrayList<Ubs> listaUbs) {
    	Collections.sort(listaUbs, Comparator.comparing(Ubs::getTotalAgendados).reversed().thenComparing(Ubs::getSigla));
    }
    
//    public void ordenaDoenca(ArrayList<String> listaDoenca) {
//    	Collections.sort(listaDoenca);
//    }
    
    
      
    
}